import React from 'react'

export default function AllCarts() {

    useEffect()
  return (
    
    <div> 
        <header>
    <h1>Home Page</h1>
    {/* Example of a Cart button */}
   
    <input
      type="text"
      id="searchBar"
      placeholder="Search..."
    />
  </header>
  
  </div>
  )
}
